#include <stdio.h>

void insertionSort (int array[], int count);
void swap (int array[], int index1, int index2);

int main(int argc, const char * argv[]) {
	int array [] = {7, 42, 0, 27, 16, 8, 4, 15, -15};
	
	int i;
	printf("\n\nUnsorted array is:  ");
	for(i = 0; i < 9; i++)
		printf(" %d ", array[i]);
	
	printf("\n");
	insertionSort(array, 9);
	
	printf("\n\nSorted array is:  ");
	for(i = 0; i < 9; i++)
		printf(" %d ", array[i]);
    return 0;
}


void insertionSort (int array[], int count) {
	//For each element in the array
	for (int i = 1; i < count; i++) {
		//Move a pointer backwards from that element
		//see if it needs to be swapped with the previous element in the array
		//and swap it as needed
		for (int j = i; j > 0 && array[j] < array[j-1]; j--) {
			swap(array, j, j-1);
		}
	}
}


void swap (int array[], int index1, int index2) {
	int tempElement = array [index1];
	array [index1] = array [index2];
	array [index2] = tempElement;
}