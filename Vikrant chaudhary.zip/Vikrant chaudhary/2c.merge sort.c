#include <stdlib.h>
#include <stdio.h>

int* merge_sort(int* ,int, int);
void merge(int*, int, int, int, int);

int main(void) {

	int *return_array_ptr;
	int array[] = {2,4,6,5,1,9,7,8,0,3,10, -1, -22, 22};
	int len = sizeof(array)/sizeof(int);

	return_array_ptr = merge_sort(array, 0, len - 1);
	int i;
	for (i = 0; i < len; ++i)
	{
		printf("%d,", *(return_array_ptr + i));
	}
	printf("\n");

	return 0 ;
}

int* merge_sort(int* array, int beg, int end) 
{
	if (end - beg == 0) {
		return array;
	}
	else {
		// split array into two pieces
		int mid = (end + beg) / 2;
		merge_sort(array, beg, mid);
		merge_sort(array, mid + 1, end);
		merge(array, beg, mid, mid + 1, end);
	}
	return array;
}

void merge(int* array, int l_beg, int l_end, int r_beg, int r_end) {
	int size = r_end - l_beg + 1;
	int *new_array = malloc(sizeof(int) * size);
	int i = 0, j = 0, k;
	for (k = 0; k < size; k++)
	{
		if (i > l_end - l_beg) {
			new_array[k] = array[r_beg + j];
			printf("%d inserted into array\n", array[r_beg + j]);
			j++;
		}
		else if (j > r_end - r_beg) 
		{
			new_array[k] = array[l_beg + i];
			printf("%d inserted into array\n", array[l_beg + i]);
			i++;
		}
		else if (array[l_beg + i] < array[r_beg + j])
		{
			new_array[k] = array[l_beg + i];
			printf("%d inserted into array\n", array[l_beg + i]);
			i++;
		}
		else if (array[r_beg + j] < array[l_beg + i]) 
		{
			new_array[k] = array[r_beg + j];
			printf("%d inserted into array\n", array[r_beg + j]);
			j++;
		}
	}

	// copy new into old positions
	int x;
	for (x = 0; x < size; x++)
	{
		array[l_beg + x] = new_array[x];
	}

	free(new_array);
}